# Recette — Filtre par liste sur la carte

Prérequis : addon déployé, au moins deux listes créées depuis la fenêtre
Découvertes, avec des objets différents dans chacune.

| # | Action | Attendu |
|---|---|---|
| 1 | Ouvrir la carte, cliquer le bouton `LC` | Le menu contient une entrée « N'afficher que : tout » |
| 2 | Ouvrir ce sous-menu | « Tout (aucun filtre) » coché, « Toutes mes listes », puis chaque liste avec son nombre d'objets |
| 3 | Choisir une liste précise | La carte ne montre plus que les objets de cette liste ; le bouton devient `LC*` |
| 4 | Rouvrir le menu | L'entrée parente affiche « N'afficher que : \<nom de la liste\> » et la bonne ligne est cochée |
| 5 | Vérifier le minimap et la liste des découvertes proches | Ils sont filtrés de la même façon — le filtrage est centralisé, c'est voulu |
| 6 | Choisir « Toutes mes listes » | Les objets de toutes les listes s'affichent, rien d'autre |
| 7 | Choisir « Tout (aucun filtre) » | Tout revient ; le bouton redevient `LC` |
| 8 | Filtrer sur une liste, puis la **supprimer** depuis la fenêtre Découvertes | La carte remontre tout, et le bouton redevient `LC` — le filtre est ignoré, pas appliqué à une autre liste |
| 9 | Filtrer sur une liste, puis la **renommer** | Même résultat qu'au point 8 |
| 10 | Recréer une liste portant le nom d'origine | Le filtre redevient actif tel quel, sans avoir à le re-sélectionner |
| 11 | Activer un filtre par liste ET « Hide Looted » | Les deux s'appliquent ensemble (filtres cumulatifs) |
| 12 | Vérifier que les listes n'ont pas changé | Les nombres d'objets affichés dans le sous-menu sont identiques à avant les manipulations |

Les points **8, 9 et 10** sont les plus importants : ils vérifient le choix de
stocker le nom de la liste plutôt que son numéro. Avec un numéro, le point 8
afficherait silencieusement le contenu d'une autre liste — un piège au lieu
d'une simple absence de filtre.

Le point **12** vérifie que le filtre est bien en lecture seule sur les listes.

## Si le filtre ne fait rien

Un seul soupçon à vérifier en premier : `LootCollector:GetFilters()` recopie ses
champs un par un, et un réglage non recopié n'atteint jamais le prédicat de
filtrage. Le symptôme est trompeur — le menu fonctionne, le réglage se
sauvegarde, et rien n'est filtré.

```bash
grep -c "combined.listFilter" LootCollector.lua
```

Attendu : `1`. Si c'est `0`, c'est ça.
