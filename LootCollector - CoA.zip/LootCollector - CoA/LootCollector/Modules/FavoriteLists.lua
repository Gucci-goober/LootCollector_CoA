-- FavoriteLists: named favorite lists with per-item notes.
-- Data layer only in this file section; UI (sidebar, popups, menus) is added
-- by later tasks below the DATA API marker.
local L = LootCollector
local FavoriteLists = L:NewModule("FavoriteLists")

local function now()
    return (type(time) == "function" and time()) or 0
end

local function trim(s)
    s = tostring(s or "")
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

function FavoriteLists:EnsureDB()
    if not (L.db and L.db.profile) then return nil end
    if not L.db.profile.favoriteLists then
        L.db.profile.favoriteLists = {}
    end
    return L.db.profile.favoriteLists
end

function FavoriteLists:GetLists()
    return self:EnsureDB() or {}
end

local function findByName(lists, name)
    for i, list in ipairs(lists) do
        if list.name == name then return i end
    end
    return nil
end

function FavoriteLists:CreateList(name)
    local lists = self:EnsureDB()
    if not lists then return nil end
    name = trim(name)
    if name == "" or findByName(lists, name) then return nil end
    table.insert(lists, { name = name, items = {} })
    return #lists
end

function FavoriteLists:RenameList(index, newName)
    local lists = self:EnsureDB()
    local list = lists and lists[index]
    if not list then return false end
    newName = trim(newName)
    if newName == "" then return false end
    local existing = findByName(lists, newName)
    if existing and existing ~= index then return false end
    list.name = newName
    return true
end

function FavoriteLists:DeleteList(index)
    local lists = self:EnsureDB()
    if not (lists and lists[index]) then return false end
    table.remove(lists, index)
    self:SetSelectedIndex(self:GetSelectedIndex()) -- re-clamp
    return true
end

function FavoriteLists:AddItem(index, itemId, note)
    local lists = self:EnsureDB()
    local list = lists and lists[index]
    if not (list and itemId) then return false end
    if not list.items[itemId] then
        list.items[itemId] = { note = note or "", added = now() }
    elseif note then
        list.items[itemId].note = note
    end
    return true
end

function FavoriteLists:RemoveItem(index, itemId)
    local lists = self:EnsureDB()
    local list = lists and lists[index]
    if not (list and itemId and list.items[itemId]) then return false end
    list.items[itemId] = nil
    return true
end

function FavoriteLists:HasItem(index, itemId)
    local lists = self:EnsureDB()
    local list = lists and lists[index]
    return (list and itemId and list.items[itemId]) and true or false
end

function FavoriteLists:SetNote(index, itemId, note)
    local lists = self:EnsureDB()
    local list = lists and lists[index]
    if not (list and itemId and list.items[itemId]) then return false end
    list.items[itemId].note = tostring(note or "")
    return true
end

function FavoriteLists:GetNote(index, itemId)
    local lists = self:EnsureDB()
    local list = lists and lists[index]
    local entry = list and itemId and list.items[itemId]
    return (entry and entry.note) or ""
end

function FavoriteLists:GetSelectedIndex()
    local lists = self:GetLists()
    local sel = (L.db and L.db.profile and L.db.profile.favoriteListsSelected) or 1
    if sel < 1 then sel = 1 end
    if #lists > 0 and sel > #lists then sel = #lists end
    if L.db and L.db.profile then L.db.profile.favoriteListsSelected = sel end
    return sel
end

function FavoriteLists:SetSelectedIndex(i)
    if L.db and L.db.profile then
        L.db.profile.favoriteListsSelected = tonumber(i) or 1
    end
    return self:GetSelectedIndex()
end

-- ===== Map list filter: pure predicates =====
-- No game API here on purpose: this is the whole decision logic for the map's
-- list filter, and keeping it API-free is what makes it verifiable outside the
-- client. Both functions are read-only -- filtering never mutates a list.

-- The label to display for a filter setting, or nil when the filter is not
-- EFFECTIVELY active. This is the single source of truth for that question:
-- the map menu, the filter-button indicator and ItemMatchesFilter all defer to
-- it. Without that, the indicator could claim a filter is on while the map
-- shows everything -- the exact confusion the indicator exists to prevent.
function FavoriteLists:ResolveFilterLabel(listFilter)
    if type(listFilter) ~= "string" or listFilter == "" then return nil end
    if listFilter == "*" then return "Toutes mes listes" end
    for _, list in ipairs(self:GetLists()) do
        if list.name == listFilter then return list.name end
    end
    -- Name no longer resolves (list deleted or renamed): treat as inactive.
    return nil
end

-- Does this item pass the given list filter?
-- An unresolvable filter is IGNORED (everything passes) rather than treated as
-- "show nothing": a broken filter must never blank the map. An unexplained empty
-- map is a costly false alarm; a map showing everything is understandable.
function FavoriteLists:ItemMatchesFilter(listFilter, itemId)
    if not self:ResolveFilterLabel(listFilter) then return true end

    itemId = tonumber(itemId)
    if not itemId or itemId <= 0 then return false end

    for _, list in ipairs(self:GetLists()) do
        if listFilter == "*" then
            if list.items and list.items[itemId] then return true end
        elseif list.name == listFilter then
            return (list.items and list.items[itemId]) and true or false
        end
    end

    return false
end

-- ===== DATA API END - UI code (sidebar, popups, context menus) below =====

local function RefreshViewer()
    local Viewer = L:GetModule("Viewer", true)
    if Viewer and Viewer.window and Viewer.window:IsShown() then
        if Viewer.InvalidateFilterCache then Viewer:InvalidateFilterCache() end
        Viewer:RefreshData()
    end
end

StaticPopupDialogs["LOOTCOLLECTOR_NEW_LIST"] = {
    text = "New list name:",
    button1 = "Create", button2 = "Cancel",
    hasEditBox = true, maxLetters = 40,
    OnAccept = function(dialog, pendingItemId)
        local editBox = _G[dialog:GetName() .. "EditBox"]
        local idx = FavoriteLists:CreateList(editBox and editBox:GetText() or "")
        if idx and pendingItemId then FavoriteLists:AddItem(idx, pendingItemId) end
        if idx then FavoriteLists:SetSelectedIndex(idx) end
        FavoriteLists:RefreshSidebar()
        RefreshViewer()
    end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

StaticPopupDialogs["LOOTCOLLECTOR_RENAME_LIST"] = {
    text = "Rename list '%s' to:",
    button1 = "Rename", button2 = "Cancel",
    hasEditBox = true, maxLetters = 40,
    OnAccept = function(dialog, listIndex)
        local editBox = _G[dialog:GetName() .. "EditBox"]
        if listIndex then FavoriteLists:RenameList(listIndex, editBox and editBox:GetText() or "") end
        FavoriteLists:RefreshSidebar()
    end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

StaticPopupDialogs["LOOTCOLLECTOR_DELETE_LIST"] = {
    text = "Delete list '%s'? Items themselves are not deleted.",
    button1 = "Delete", button2 = "Cancel",
    OnAccept = function(dialog, listIndex)
        if listIndex then FavoriteLists:DeleteList(listIndex) end
        FavoriteLists:RefreshSidebar()
        RefreshViewer()
    end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

StaticPopupDialogs["LOOTCOLLECTOR_EDIT_NOTE"] = {
    text = "Note for this item:",
    button1 = "Save", button2 = "Cancel",
    hasEditBox = true, maxLetters = 120,
    OnAccept = function(dialog, itemId)
        local editBox = _G[dialog:GetName() .. "EditBox"]
        if itemId then
            FavoriteLists:SetNote(FavoriteLists:GetSelectedIndex(), itemId, editBox and editBox:GetText() or "")
        end
        RefreshViewer()
    end,
    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}

function FavoriteLists:OpenNotePopup(itemId)
    local dialog = StaticPopup_Show("LOOTCOLLECTOR_EDIT_NOTE")
    if dialog then
        dialog.data = itemId
        local editBox = _G[dialog:GetName() .. "EditBox"]
        if editBox then
            editBox:SetText(self:GetNote(self:GetSelectedIndex(), itemId))
            editBox:HighlightText()
        end
    end
end

function FavoriteLists:EnsureSidebar()
    if self.sidebar then return self.sidebar end
    local Viewer = L:GetModule("Viewer", true)
    if not (Viewer and Viewer.window) then return nil end
    local f = CreateFrame("Frame", "LootCollectorMyListsSidebar", Viewer.window)
    f:SetWidth(185)
    f:SetPoint("TOPRIGHT", Viewer.window, "TOPLEFT", 0, 0)
    f:SetPoint("BOTTOMRIGHT", Viewer.window, "BOTTOMLEFT", 0, 0)
    f:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
    })
    f:SetBackdropColor(0.05, 0.05, 0.08, 0.95)
    f:SetBackdropBorderColor(0.30, 0.30, 0.40, 0.80)
    f:EnableMouse(true)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 10, -10)
    title:SetText("My Lists")

    local newBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    newBtn:SetSize(165, 22)
    newBtn:SetPoint("BOTTOMLEFT", 10, 10)
    newBtn:SetText("+ New list")
    newBtn:SetScript("OnClick", function()
        StaticPopup_Show("LOOTCOLLECTOR_NEW_LIST")
    end)

    f.listButtons = {}
    self.sidebar = f
    return f
end

function FavoriteLists:RefreshSidebar()
    local f = self:EnsureSidebar()
    if not f then return end
    local lists = self:GetLists()
    local selected = self:GetSelectedIndex()
    for _, btn in ipairs(f.listButtons) do btn:Hide() end
    local prev = nil
    for i, list in ipairs(lists) do
        local btn = f.listButtons[i]
        if not btn then
            btn = CreateFrame("Button", nil, f)
            btn:SetSize(165, 20)
            btn.bg = btn:CreateTexture(nil, "BACKGROUND")
            btn.bg:SetAllPoints(true)
            btn.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
            btn.label = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            btn.label:SetPoint("LEFT", 6, 0)
            btn.label:SetJustifyH("LEFT")
            btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            f.listButtons[i] = btn
        end
        if prev then
            btn:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -4)
        else
            btn:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -35)
        end
        local count = 0
        for _ in pairs(list.items) do count = count + 1 end
        btn.label:SetText(list.name .. " |cffaaaaaa(" .. count .. ")|r")
        if i == selected then
            btn.bg:SetVertexColor(0.12, 0.22, 0.38, 1)
        else
            btn.bg:SetVertexColor(0.10, 0.10, 0.14, 0.9)
        end
        btn:SetScript("OnClick", function(_, mouseButton)
            if mouseButton == "RightButton" then
                local Viewer = L:GetModule("Viewer", true)
                if Viewer and Viewer._CreateContextMenu then
                    Viewer._CreateContextMenu(btn, list.name, {
                        { text = "Rename...", onClick = function()
                            local dialog = StaticPopup_Show("LOOTCOLLECTOR_RENAME_LIST", list.name)
                            if dialog then dialog.data = i end
                        end },
                        { text = "Delete...", onClick = function()
                            local dialog = StaticPopup_Show("LOOTCOLLECTOR_DELETE_LIST", list.name)
                            if dialog then dialog.data = i end
                        end },
                    })
                end
            else
                FavoriteLists:SetSelectedIndex(i)
                FavoriteLists:RefreshSidebar()
                RefreshViewer()
            end
        end)
        btn:Show()
        prev = btn
    end
end

function FavoriteLists:ShowSidebar(visible)
    if visible then
        local f = self:EnsureSidebar()
        if f then
            self:RefreshSidebar()
            f:Show()
        end
    elseif self.sidebar then
        self.sidebar:Hide()
    end
end

function FavoriteLists:OpenAddToListMenu(anchor, itemId)
    local Viewer = L:GetModule("Viewer", true)
    if not (Viewer and Viewer._CreateContextMenu and itemId) then return end
    local buttons = {}
    for i, list in ipairs(self:GetLists()) do
        local has = self:HasItem(i, itemId)
        local prefix = has and "|cff33ff33[x]|r " or "[  ] "
        table.insert(buttons, { text = prefix .. list.name, onClick = function()
            if has then
                FavoriteLists:RemoveItem(i, itemId)
            else
                FavoriteLists:AddItem(i, itemId)
            end
            FavoriteLists:RefreshSidebar()
            RefreshViewer()
        end })
    end
    table.insert(buttons, { text = "+ New list...", onClick = function()
        local dialog = StaticPopup_Show("LOOTCOLLECTOR_NEW_LIST")
        if dialog then dialog.data = itemId end
    end })
    Viewer._CreateContextMenu(anchor, "Add to list", buttons)
end
